#!/usr/bin/env python3
"""在完全相同的输入上比较旧/新波形算法。

该工具执行三层比较：

1. 分别以旧/新默认算法编译并运行既有 ``host_test.c.txt``（2400 例）；
2. 分别运行既有 ``precision_validation.c.txt``（2400 例）；
3. 对赛事门禁与挑战用例逐帧调用 A/B 选择接口，同时记录确定性工作量和
   主机墙钟时间，生成 JSON、CSV 与 Markdown 对比矩阵。

墙钟时间只适合比较同一台主机上的相对开销；``waveform_complexity_t`` 中
的循环规模才是跨主机、CCS 与目标板都一致的记录口径。
"""

from __future__ import annotations

import argparse
import csv
import ctypes
import json
import math
from pathlib import Path
import re
import statistics
import subprocess
import sys
import tempfile
import time
from typing import Iterable

import competition_stress_suite as stress


ALGORITHMS = {
    "legacy_amdf_crossing": 0,
    "global_harmonic_model": 1,
}

COMPLEXITY_FIELDS = [
    "input_samples",
    "period_search_points",
    "difference_evaluations",
    "crossing_samples",
    "spectral_frequency_evaluations",
    "spectral_sample_evaluations",
    "harmonic_mac_pairs",
    "model_frequency_evaluations",
    "fold_interpolations",
    "template_evaluations",
    "template_point_evaluations",
    "coarse_frequency_millihz",
    "refined_frequency_millihz",
    "static_workspace_bytes",
]


class WaveformComplexity(ctypes.Structure):
    """``waveform_complexity_t`` 的 ctypes 镜像。"""

    _fields_ = [
        ("algorithm", ctypes.c_int),
        *[(name, ctypes.c_uint32) for name in COMPLEXITY_FIELDS],
    ]


def percentile(values: Iterable[float], fraction: float) -> float:
    """用线性插值求分位数；空序列返回 0。"""
    ordered = sorted(values)
    if not ordered:
        return 0.0
    position = (len(ordered) - 1) * fraction
    lower = math.floor(position)
    upper = math.ceil(position)
    if lower == upper:
        return float(ordered[lower])
    weight = position - lower
    return ordered[lower] * (1.0 - weight) + ordered[upper] * weight


def configure_library(path: Path):
    """加载共享库并声明 A/B 选择器的精确签名。"""
    library = stress.load_library(path)
    library.waveform_analyze_frame_with_algorithm.argtypes = [
        ctypes.POINTER(stress.WaveformFrame),
        ctypes.POINTER(stress.WaveformResult),
        ctypes.c_int,
        ctypes.POINTER(WaveformComplexity),
    ]
    library.waveform_analyze_frame_with_algorithm.restype = ctypes.c_bool
    return library


def evaluate_result(case: stress.Case, result: stress.WaveformResult,
                    valid: bool, thresholds: dict[str, float]) -> dict[str, object]:
    """按既有压力测试完全相同的阈值评估一个输出。"""
    got_kind = (stress.TYPE_NAME[result.type]
                if 0 <= result.type < len(stress.TYPE_NAME) else "invalid")
    status = (stress.STATUS_NAME[result.status]
              if 0 <= result.status < len(stress.STATUS_NAME)
              else "INVALID_STATUS")
    measured_frequency = result.frequency_millihz / 1000.0
    expected_vpp_uv = (
        case.vpp_counts * case.reference_uv / stress.ADC_FULL_SCALE
        * 1_000_000.0 / case.gain_ppm
    )
    frequency_error = (abs(measured_frequency - case.frequency_hz)
                       / case.frequency_hz * 100.0 if valid else 100.0)
    vpp_error = (abs(result.vpp_microvolts - expected_vpp_uv)
                 / expected_vpp_uv * 100.0 if valid else 100.0)
    duty_error = (abs(result.duty_ppm / 1_000_000.0 - case.duty) * 100.0
                  if valid and case.kind == "square" else 0.0)
    passed = (
        valid and status == "OK" and got_kind == case.kind
        and frequency_error <= thresholds["frequency_error_pct"]
        and vpp_error <= thresholds["vpp_error_pct"]
        and duty_error <= thresholds["duty_error_pp"]
    )
    return {
        "valid": valid,
        "status": status,
        "got_kind": got_kind,
        "measured_frequency_hz": measured_frequency,
        "measured_vpp_uv": result.vpp_microvolts,
        "measured_duty_pct": (
            result.duty_ppm / 10_000.0
            if case.kind == "square" and valid else None
        ),
        "frequency_error_pct": frequency_error,
        "vpp_error_pct": vpp_error,
        "duty_error_pp": duty_error,
        "best_score_permille": result.best_score_permille,
        "model_margin_permille": result.model_margin_permille,
        "accepted_cycles": result.accepted_cycles,
        "passed": passed,
    }


def analyze_pair(library, case: stress.Case, sequence: int, seed: int,
                 thresholds: dict[str, float]) -> dict[str, object]:
    """一次生成样本，交替调用顺序后分别运行旧/新算法。"""
    samples = stress.generate_samples(case, seed)
    array = (ctypes.c_uint16 * stress.SAMPLE_COUNT)(*samples)
    frame = stress.WaveformFrame(
        samples=array,
        sample_count=stress.SAMPLE_COUNT,
        adc_full_scale=stress.ADC_FULL_SCALE,
        sample_rate_millihz=int(round(case.sample_rate_hz * 1000.0)),
        adc_reference_microvolts=case.reference_uv,
        frontend_gain_ppm=case.gain_ppm,
        sequence=sequence,
        flags=(stress.FRAME_CONTIGUOUS | stress.FRAME_CLOCK_CALIBRATED
               | stress.FRAME_VREF_CALIBRATED),
    )
    names = list(ALGORITHMS)
    # 交替先后顺序，降低共享 CPU 缓存和温度对某一算法的固定偏置。
    order = names if sequence % 2 else list(reversed(names))
    outputs: dict[str, object] = {}
    for name in order:
        result = stress.WaveformResult()
        complexity = WaveformComplexity()
        start = time.perf_counter_ns()
        valid = bool(library.waveform_analyze_frame_with_algorithm(
            ctypes.byref(frame), ctypes.byref(result), ALGORITHMS[name],
            ctypes.byref(complexity)
        ))
        elapsed_ns = time.perf_counter_ns() - start
        if result.algorithm_version != stress.ALGORITHM_VERSION:
            raise RuntimeError(
                f"{name}: algorithm version {result.algorithm_version:#010x} "
                f"!= {stress.ALGORITHM_VERSION:#010x}"
            )
        evaluated = evaluate_result(case, result, valid, thresholds)
        evaluated["elapsed_ns"] = elapsed_ns
        evaluated["complexity"] = {
            "algorithm": complexity.algorithm,
            **{field: getattr(complexity, field)
               for field in COMPLEXITY_FIELDS},
        }
        outputs[name] = evaluated
    return {
        "sequence": sequence,
        "case": stress.asdict(case),
        "algorithms": outputs,
    }


def summarize_rows(rows: list[dict[str, object]], algorithm: str) -> dict[str, object]:
    """汇总一个数据组中指定算法的精度、耗时与工作量。"""
    outputs = [row["algorithms"][algorithm] for row in rows]
    elapsed_us = [output["elapsed_ns"] / 1000.0 for output in outputs]
    complexity_summary: dict[str, object] = {}
    for field in COMPLEXITY_FIELDS:
        values = [output["complexity"][field] for output in outputs]
        complexity_summary[field] = {
            "mean": statistics.fmean(values),
            "max": max(values),
            "total": sum(values),
        }
    return {
        "total": len(outputs),
        "passes": sum(bool(output["passed"]) for output in outputs),
        "status_ok": sum(output["status"] == "OK" for output in outputs),
        "class_correct": sum(
            output["got_kind"] == row["case"]["kind"]
            for output, row in zip(outputs, rows)
        ),
        "max_frequency_error_pct": max(
            output["frequency_error_pct"] for output in outputs
        ),
        "max_vpp_error_pct": max(output["vpp_error_pct"] for output in outputs),
        "max_duty_error_pp": max(output["duty_error_pp"] for output in outputs),
        "mean_frequency_error_pct": statistics.fmean(
            output["frequency_error_pct"] for output in outputs
        ),
        "mean_vpp_error_pct": statistics.fmean(
            output["vpp_error_pct"] for output in outputs
        ),
        "host_time_us": {
            "total": sum(elapsed_us),
            "mean": statistics.fmean(elapsed_us),
            "p95": percentile(elapsed_us, 0.95),
            "max": max(elapsed_us),
        },
        "complexity": complexity_summary,
        "failures": [
            {"sequence": row["sequence"], "case": row["case"], "output": output}
            for row, output in zip(rows, outputs) if not output["passed"]
        ][:12],
    }


def paired_summary(rows: list[dict[str, object]]) -> dict[str, int]:
    """统计新方案相对旧方案的逐帧通过/退化关系。"""
    result = {
        "both_pass": 0,
        "legacy_only_pass": 0,
        "global_only_pass": 0,
        "both_fail": 0,
    }
    for row in rows:
        legacy = row["algorithms"]["legacy_amdf_crossing"]["passed"]
        global_model = row["algorithms"]["global_harmonic_model"]["passed"]
        if legacy and global_model:
            result["both_pass"] += 1
        elif legacy:
            result["legacy_only_pass"] += 1
        elif global_model:
            result["global_only_pass"] += 1
        else:
            result["both_fail"] += 1
    return result


C_SUITE_PATTERNS = {
    "host_test": re.compile(
        r"cases=(?P<total>\d+) class_fail=(?P<class_fail>\d+) "
        r"measurement_fail=(?P<measurement_fail>\d+) "
        r"contract_fail=(?P<contract_fail>\d+) "
        r"worst_freq=(?P<worst_freq>[0-9.]+)% "
        r"worst_vpp=(?P<worst_vpp>[0-9.]+)% "
        r"worst_duty=(?P<worst_duty>[0-9.]+)"
    ),
    "precision_validation": re.compile(
        r"strong_cases=(?P<total>\d+) class_fail=(?P<class_fail>\d+) "
        r"measurement_fail=(?P<measurement_fail>\d+) "
        r"worst_freq=(?P<worst_freq>[0-9.]+)% "
        r"worst_vpp=(?P<worst_vpp>[0-9.]+)% "
        r"worst_duty=(?P<worst_duty>[0-9.]+)"
    ),
}


def run_existing_c_suites(project_dir: Path) -> dict[str, object]:
    """用两种默认算法分别编译、执行原有两组 C 回归。"""
    sources = {
        "host_test": project_dir / "tests" / "host_test.c.txt",
        "precision_validation": project_dir / "tests" / "precision_validation.c.txt",
    }
    report: dict[str, object] = {}
    with tempfile.TemporaryDirectory(prefix="waveform-ab-") as temp_dir_name:
        temp_dir = Path(temp_dir_name)
        for algorithm, enum_value in ALGORITHMS.items():
            report[algorithm] = {}
            for suite, source in sources.items():
                executable = temp_dir / f"{algorithm}-{suite}"
                command = [
                    "cc", "-std=c99", "-O2", "-Wall", "-Wextra", "-Werror",
                    f"-DWAVEFORM_DEFAULT_ALGORITHM={enum_value}",
                    f"-I{project_dir}", str(project_dir / "waveform_analyzer.c"),
                    "-x", "c", str(source), "-lm", "-o", str(executable),
                ]
                subprocess.run(command, check=True, capture_output=True, text=True)
                start = time.perf_counter_ns()
                completed = subprocess.run(
                    [str(executable)], capture_output=True, text=True, check=False
                )
                elapsed_ns = time.perf_counter_ns() - start
                output = completed.stdout + completed.stderr
                match = C_SUITE_PATTERNS[suite].search(output)
                if match is None:
                    raise RuntimeError(f"cannot parse {algorithm}/{suite}: {output}")
                parsed = {
                    key: (float(value) if key.startswith("worst_") else int(value))
                    for key, value in match.groupdict().items()
                }
                parsed.update({
                    "exit_code": completed.returncode,
                    "elapsed_ms": elapsed_ns / 1_000_000.0,
                    "stdout": output.strip(),
                })
                report[algorithm][suite] = parsed
    return report


def measure_host_object_sections(project_dir: Path) -> dict[str, int]:
    """记录双分支核心在当前主机编译器下的 text/data/bss，便于追踪体积。"""
    with tempfile.TemporaryDirectory(prefix="waveform-size-") as temp_dir_name:
        object_path = Path(temp_dir_name) / "waveform_analyzer.o"
        subprocess.run([
            "cc", "-std=c99", "-O2", "-Wall", "-Wextra", "-Werror",
            f"-I{project_dir}", "-c", str(project_dir / "waveform_analyzer.c"),
            "-o", str(object_path),
        ], check=True, capture_output=True, text=True)
        completed = subprocess.run(
            ["size", str(object_path)], check=True, capture_output=True, text=True
        )
    columns = completed.stdout.strip().splitlines()[-1].split()
    if len(columns) < 4:
        raise RuntimeError(f"cannot parse size output: {completed.stdout}")
    return {
        "text_bytes": int(columns[0]),
        "data_bytes": int(columns[1]),
        "bss_bytes": int(columns[2]),
        "total_bytes": int(columns[3]),
    }


def format_markdown(report: dict[str, object]) -> str:
    """把机器报告渲染成人可审阅的对比矩阵。"""
    lines = [
        "# 新旧波形算法 A/B 对比",
        "",
        f"固定随机种子：`{report['seed']}`。两套算法对每个压力用例使用完全相同的 ADC 数组；调用顺序逐例交替。",
        "",
        "## 既有测试矩阵",
        "",
        "| 测试组 | 算法 | 通过/总数 | 分类失败 | 测量失败 | 最坏频率误差 | 最坏 Vpp 误差 | 最坏占空比误差 | 主机耗时 |",
        "| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    c_suites = report["existing_c_suites"]
    suite_labels = {
        "host_test": "初赛强度",
        "precision_validation": "强干扰",
    }
    for suite, label in suite_labels.items():
        for algorithm in ALGORITHMS:
            item = c_suites[algorithm][suite]
            failures = item["class_fail"] + item["measurement_fail"] + item.get("contract_fail", 0)
            passed = item["total"] - failures
            lines.append(
                f"| {label} | `{algorithm}` | {passed}/{item['total']} | "
                f"{item['class_fail']} | {item['measurement_fail']} | "
                f"{item['worst_freq']:.4f}% | {item['worst_vpp']:.3f}% | "
                f"{item['worst_duty']:.3f} pp | {item['elapsed_ms']:.1f} ms |"
            )
    summaries = report["summaries"]
    for group, label in (("preliminary_gate", "严格初赛门禁"),
                         ("competition_challenge", "赛事迁移挑战")):
        for algorithm in ALGORITHMS:
            item = summaries[group][algorithm]
            lines.append(
                f"| {label} | `{algorithm}` | {item['passes']}/{item['total']} | "
                f"{item['total'] - item['class_correct']} | "
                f"{item['total'] - item['passes']} | "
                f"{item['max_frequency_error_pct']:.4f}% | "
                f"{item['max_vpp_error_pct']:.3f}% | "
                f"{item['max_duty_error_pp']:.3f} pp | "
                f"{item['host_time_us']['total'] / 1000.0:.1f} ms |"
            )

    lines.extend([
        "",
        "## 逐帧胜负关系",
        "",
        "| 测试组 | 两者通过 | 仅旧方案通过 | 仅新方案通过 | 两者失败 |",
        "| --- | ---: | ---: | ---: | ---: |",
    ])
    for group, label in (("preliminary_gate", "严格初赛门禁"),
                         ("competition_challenge", "赛事迁移挑战")):
        pair = report["paired"][group]
        lines.append(
            f"| {label} | {pair['both_pass']} | {pair['legacy_only_pass']} | "
            f"{pair['global_only_pass']} | {pair['both_fail']} |"
        )

    lines.extend([
        "",
        "## 确定性计算复杂度",
        "",
        "下表为赛事门禁与挑战合并后的每帧平均值；`harmonic MAC pair` 表示同一样本/谐波的一对正交 sin/cos 乘累加。",
        "",
        "| 算法 | AMDF 差值/帧 | 谱频点/帧 | 谱样本/帧 | harmonic MAC pair/帧 | 交越扫描/帧 | 模型频点/帧 | 折叠插值/帧 | 模板点/帧 | 静态工作区 |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ])
    combined = report["summaries"]["combined"]
    for algorithm in ALGORITHMS:
        complexity = combined[algorithm]["complexity"]
        mean = lambda field: complexity[field]["mean"]
        lines.append(
            f"| `{algorithm}` | {mean('difference_evaluations'):.0f} | "
            f"{mean('spectral_frequency_evaluations'):.0f} | "
            f"{mean('spectral_sample_evaluations'):.0f} | "
            f"{mean('harmonic_mac_pairs'):.0f} | {mean('crossing_samples'):.0f} | "
            f"{mean('model_frequency_evaluations'):.2f} | "
            f"{mean('fold_interpolations'):.0f} | "
            f"{mean('template_point_evaluations'):.0f} | "
            f"{mean('static_workspace_bytes'):.0f} B |"
        )

    sections = report["host_object_sections"]
    lines.extend([
        "",
        f"当前双分支核心用主机 `cc -O2` 编译的对象段大小为：text {sections['text_bytes']} B、data {sections['data_bytes']} B、bss {sections['bss_bytes']} B。两套运行时分支共用工作数组；表中的 {combined['global_harmonic_model']['complexity']['static_workspace_bytes']['mean']:.0f} B 是显式算法数组之和，BSS 还包含记录指针与链接器对齐。目标板 Flash/RAM 数值必须以 CCS Release map 为准。",
    ])

    legacy_challenge = summaries["competition_challenge"]["legacy_amdf_crossing"]
    global_challenge = summaries["competition_challenge"]["global_harmonic_model"]
    lines.extend([
        "",
        "## 结论",
        "",
        f"- 严格初赛门禁：旧方案 {summaries['preliminary_gate']['legacy_amdf_crossing']['passes']}/{summaries['preliminary_gate']['legacy_amdf_crossing']['total']}，新方案 {summaries['preliminary_gate']['global_harmonic_model']['passes']}/{summaries['preliminary_gate']['global_harmonic_model']['total']}。",
        f"- 赛事迁移挑战：旧方案 {legacy_challenge['passes']}/{legacy_challenge['total']}，新方案 {global_challenge['passes']}/{global_challenge['total']}。",
        "- 新方案的完整频带扫描消除了旧方案已知的四倍周期漏判；精细频率仍由受全局解约束的交越回归完成，交越不可用时才启动类别条件的局部模型搜索。",
        "- 主机墙钟结果包含 CPU、编译器和缓存影响，不能替代 MSPM0G3507 Release/O2 的 GPIO 或周期计数器实测。确定性循环计数给出了可复查的相对复杂度，但也不是精确 CPU cycle。",
        "",
    ])
    return "\n".join(lines)


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    """写逐例的扁平 A/B 矩阵，便于表格筛选。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "sequence", "group", "impairment", "kind", "frequency_hz",
        "vpp_counts", "duty", "legacy_pass", "legacy_status",
        "legacy_kind", "legacy_frequency_error_pct", "legacy_vpp_error_pct",
        "legacy_duty_error_pp", "legacy_elapsed_us", "global_pass",
        "global_status", "global_kind", "global_frequency_error_pct",
        "global_vpp_error_pct", "global_duty_error_pp", "global_elapsed_us",
    ]
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            case = row["case"]
            legacy = row["algorithms"]["legacy_amdf_crossing"]
            global_model = row["algorithms"]["global_harmonic_model"]
            writer.writerow({
                "sequence": row["sequence"],
                "group": case["group"],
                "impairment": case["impairment"],
                "kind": case["kind"],
                "frequency_hz": case["frequency_hz"],
                "vpp_counts": case["vpp_counts"],
                "duty": case["duty"],
                "legacy_pass": legacy["passed"],
                "legacy_status": legacy["status"],
                "legacy_kind": legacy["got_kind"],
                "legacy_frequency_error_pct": legacy["frequency_error_pct"],
                "legacy_vpp_error_pct": legacy["vpp_error_pct"],
                "legacy_duty_error_pp": legacy["duty_error_pp"],
                "legacy_elapsed_us": legacy["elapsed_ns"] / 1000.0,
                "global_pass": global_model["passed"],
                "global_status": global_model["status"],
                "global_kind": global_model["got_kind"],
                "global_frequency_error_pct": global_model["frequency_error_pct"],
                "global_vpp_error_pct": global_model["vpp_error_pct"],
                "global_duty_error_pp": global_model["duty_error_pp"],
                "global_elapsed_us": global_model["elapsed_ns"] / 1000.0,
            })


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--library", type=Path, required=True)
    parser.add_argument("--json", type=Path,
                        default=Path("tests/results/algorithm_comparison.json"))
    parser.add_argument("--csv", type=Path,
                        default=Path("tests/results/algorithm_comparison.csv"))
    parser.add_argument("--markdown", type=Path,
                        default=Path("docs/ALGORITHM_AB_COMPARISON.md"))
    parser.add_argument("--seed", type=int, default=20260919)
    parser.add_argument("--gate-cases-per-kind", type=int, default=96)
    parser.add_argument("--challenge-cases-per-profile", type=int, default=12)
    args = parser.parse_args()

    project_dir = Path(__file__).resolve().parent.parent
    library = configure_library(args.library.resolve())
    gate_thresholds = {
        "frequency_error_pct": 0.50,
        "vpp_error_pct": 8.0,
        "duty_error_pp": 2.0,
    }
    challenge_thresholds = {
        "frequency_error_pct": 1.0,
        "vpp_error_pct": 12.0,
        "duty_error_pp": 3.0,
    }
    gate = stress.gate_cases(args.seed, args.gate_cases_per_kind)
    challenge = stress.challenge_cases(args.seed, args.challenge_cases_per_profile)
    gate_rows = [
        analyze_pair(library, case, index + 1, args.seed + index * 7919,
                     gate_thresholds)
        for index, case in enumerate(gate)
    ]
    challenge_rows = [
        analyze_pair(library, case, len(gate) + index + 1,
                     args.seed ^ (index * 104729), challenge_thresholds)
        for index, case in enumerate(challenge)
    ]
    all_rows = gate_rows + challenge_rows
    summaries = {
        "preliminary_gate": {
            name: summarize_rows(gate_rows, name) for name in ALGORITHMS
        },
        "competition_challenge": {
            name: summarize_rows(challenge_rows, name) for name in ALGORITHMS
        },
        "combined": {
            name: summarize_rows(all_rows, name) for name in ALGORITHMS
        },
    }
    report = {
        "schema_version": 1,
        "seed": args.seed,
        "algorithm_version": stress.ALGORITHM_VERSION,
        "host_object_sections": measure_host_object_sections(project_dir),
        "existing_c_suites": run_existing_c_suites(project_dir),
        "thresholds": {
            "preliminary_gate": gate_thresholds,
            "competition_challenge": challenge_thresholds,
        },
        "summaries": summaries,
        "paired": {
            "preliminary_gate": paired_summary(gate_rows),
            "competition_challenge": paired_summary(challenge_rows),
        },
        "rows": all_rows,
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_csv(args.csv, all_rows)
    args.markdown.parent.mkdir(parents=True, exist_ok=True)
    args.markdown.write_text(format_markdown(report), encoding="utf-8")

    for group in ("preliminary_gate", "competition_challenge"):
        pair = report["paired"][group]
        print(
            f"{group}: both={pair['both_pass']} legacy_only="
            f"{pair['legacy_only_pass']} global_only={pair['global_only_pass']} "
            f"both_fail={pair['both_fail']}"
        )
    print(f"json={args.json}")
    print(f"csv={args.csv}")
    print(f"markdown={args.markdown}")

    gate_new = summaries["preliminary_gate"]["global_harmonic_model"]
    c_suites = report["existing_c_suites"]["global_harmonic_model"]
    return 0 if (
        gate_new["passes"] == gate_new["total"]
        and c_suites["host_test"]["exit_code"] == 0
        and c_suites["precision_validation"]["exit_code"] == 0
    ) else 1


if __name__ == "__main__":
    sys.exit(main())
