#!/usr/bin/env bash
# 构建同源主机共享库，并在完全相同输入上运行旧/新算法 A/B 对比。
set -euo pipefail

script_dir="$(cd "$(dirname "$0")" && pwd)"
project_dir="$(cd "$script_dir/.." && pwd)"

cc -std=c99 -O2 -Wall -Wextra -Werror -fPIC -shared \
  -I"$project_dir" \
  "$project_dir/waveform_analyzer.c" \
  -lm -o "$script_dir/waveform_analyzer_host.so"

python3 -B "$project_dir/tools/compare_algorithms.py" \
  --library "$script_dir/waveform_analyzer_host.so" \
  --json "$script_dir/results/algorithm_comparison.json" \
  --csv "$script_dir/results/algorithm_comparison.csv" \
  --markdown "$project_dir/docs/ALGORITHM_AB_COMPARISON.md"
