################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
SYSCFG_SRCS += \
../empty.syscfg 

C_SRCS += \
../empty.c \
./ti_msp_dl_config.c \
C:/ti/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/gcc/startup_mspm0g350x_gcc.c \
../waveform_analyzer.c 

GEN_CMDS += \
./device_linker.lds 

GEN_FILES += \
./device_linker.lds \
./device.opt \
./ti_msp_dl_config.c 

C_DEPS += \
./empty.d \
./ti_msp_dl_config.d \
./startup_mspm0g350x_gcc.d \
./waveform_analyzer.d 

GEN_OPTS += \
./device.opt 

OBJS += \
./empty.o \
./ti_msp_dl_config.o \
./startup_mspm0g350x_gcc.o \
./waveform_analyzer.o 

GEN_MISC_FILES += \
./device.lds.genlibs \
./ti_msp_dl_config.h \
./Event.dot 

OBJS__QUOTED += \
"empty.o" \
"ti_msp_dl_config.o" \
"startup_mspm0g350x_gcc.o" \
"waveform_analyzer.o" 

GEN_MISC_FILES__QUOTED += \
"device.lds.genlibs" \
"ti_msp_dl_config.h" \
"Event.dot" 

C_DEPS__QUOTED += \
"empty.d" \
"ti_msp_dl_config.d" \
"startup_mspm0g350x_gcc.d" \
"waveform_analyzer.d" 

GEN_FILES__QUOTED += \
"device_linker.lds" \
"device.opt" \
"ti_msp_dl_config.c" 

C_SRCS__QUOTED += \
"../empty.c" \
"./ti_msp_dl_config.c" \
"C:/ti/mspm0_sdk_2_11_00_07/source/ti/devices/msp/m0p/startup_system_files/gcc/startup_mspm0g350x_gcc.c" \
"../waveform_analyzer.c" 

SYSCFG_SRCS__QUOTED += \
"../empty.syscfg" 


