# FIXED

waveform_analyzer.o: ../waveform_analyzer.c ../waveform_analyzer.h

../waveform_analyzer.h:
